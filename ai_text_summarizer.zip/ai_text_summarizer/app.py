"""Beginner-friendly AI Text Summarizer built with Streamlit and an LLM."""

import os

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI

# Load secrets from the local .env file.
load_dotenv()

st.set_page_config(page_title="AI Text Summarizer", page_icon="📝", layout="centered")
st.title("📝 AI Text Summarizer")
st.write("Paste a paragraph or article, choose the summary length, and let AI summarize it.")

text = st.text_area(
    "Text to summarize",
    height=260,
    placeholder="Paste your article or notes here...",
)
summary_length = st.selectbox("Summary length", ["Short", "Medium", "Detailed"])

if st.button("Summarize", type="primary", use_container_width=True):
    if not text.strip():
        st.warning("Please paste some text first.")
    else:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            st.error("API key not found. Add OPENAI_API_KEY=your_key to your .env file, then restart the app.")
        else:
            instructions = (
                "You are a helpful summarization assistant. Summarize only the information in the user's text. "
                "Do not invent facts. Use simple, clear English. "
                f"Make the summary {summary_length.lower()} in length."
            )
            try:
                client = OpenAI(api_key=api_key)
                with st.spinner("Creating your summary..."):
                    response = client.responses.create(
                        model=os.getenv("OPENAI_MODEL", "gpt-6-luna"),
                        instructions=instructions,
                        input=text,
                    )
                st.subheader("Your summary")
                st.write(response.output_text)
            except Exception as exc:
                st.error("The summary could not be created. Check your API key, model access, and internet connection.")
                # Show a short diagnostic to help a beginner troubleshoot without exposing secrets.
                st.caption(f"Technical detail: {type(exc).__name__}: {exc}")

st.divider()
st.caption("Beginner project: Python + Streamlit + OpenAI API")
