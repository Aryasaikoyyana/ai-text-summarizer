# AI Text Summarizer (Beginner Project)

A very simple LLM project: paste text into a web page and use an AI model to summarize it.

## What you need

- Python 3.10 or newer
- Internet access
- An OpenAI API key with API access (API use may cost money; ChatGPT subscriptions and API billing are separate)

## Run it on Windows

1. Extract this folder and open it in VS Code.
2. Open Terminal in VS Code.
3. Create a virtual environment:

   ```powershell
   python -m venv .venv
   ```

4. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, open Command Prompt and run:

   ```bat
   .venv\Scripts\activate.bat
   ```

5. Install the packages:

   ```bash
   pip install -r requirements.txt
   ```

6. Copy `.env.example` to a new file named `.env`.
7. Open `.env` and replace `put_your_api_key_here` with your API key. Do not share this file or upload it to GitHub.
8. Run the app:

   ```bash
   streamlit run app.py
   ```

9. A browser page will open. Paste text, choose a summary length, and click **Summarize**.

## How it works

1. Streamlit displays the text box and button.
2. When you click **Summarize**, Python checks that text and an API key are present.
3. The app sends the text and summarization instructions to the LLM through the OpenAI Responses API.
4. The app displays the model's summary.

## Common issues

- **API key not found:** confirm that the file is named `.env` (not `.env.txt`) and restart the app.
- **Authentication error:** make sure the key is copied correctly and active.
- **Model not available:** replace `OPENAI_MODEL` in `.env` with a model ID available to your API account.
- **Billing or quota error:** check your API billing and usage limits.

## Easy improvements after the first version

- Add a button to rewrite text as bullet points.
- Add a language selector.
- Add download-summary as a `.txt` file.
- Add a word count before and after summarization.

## Resume description

**AI Text Summarizer | Python, Streamlit, LLM API**  
Built a web app that summarizes user-provided text using a large language model, with adjustable summary length, input validation, and error handling.
